//index.js  
//获取应用实例  
var app = getApp()
//博客地址:http://blog.csdn.net/qq_31383345
//CSDN微信小程序开发专栏:http://blog.csdn.net/column/details/13721.html
Page({
  data: {
    currentTab: 0,
    grids: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    swiperList:[0, 1, 2, 3, 4]
  },
  onLoad: function () {
  },
  click: function (e) {
    console.log(e.currentTarget.dataset.id)
    console.log(e.currentTarget.dataset.index)
    wx.showToast({
      title: '第' + e.currentTarget.dataset.id + '栏' + '第' + e.currentTarget.dataset.index + '个',
      icon: 'success',
      duration: 1500
    })
  },
  /** 
     * 滑动切换tab 
     */
  bindChange: function (e) {
    console.log(e.detail.current)
    this.setData({ currentTab: e.detail.current });
  },
})


